/*
==============================================
  AUTHENTICATION & SESSION MANAGEMENT
==============================================
  Handles user authentication, authorization, and session
*/

// ============================================
// 1. AUTHENTICATION STATE
// ============================================

const Auth = {
    // Storage keys
    STORAGE_KEYS: {
        USER: 'motel_current_user',
        USERS: 'motel_users',
        SESSION: 'motel_session'
    },

    // User roles
    ROLES: {
        ADMIN: 'admin',
        TENANT: 'tenant'
    },

    /**
     * Initialize auth system with demo data
     */
    init() {
        // Create demo users if not exists
        if (!Storage.get(this.STORAGE_KEYS.USERS)) {
            const demoUsers = [
                {
                    id: 'admin1',
                    email: 'admin@motel.com',
                    password: 'admin123', // In production, this should be hashed
                    fullName: 'Quản lý Nhà trọ',
                    phone: '0901234567',
                    role: this.ROLES.ADMIN,
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'tenant1',
                    email: 'tenant@example.com',
                    password: 'tenant123',
                    fullName: 'Nguyễn Văn A',
                    phone: '0912345678',
                    role: this.ROLES.TENANT,
                    roomId: 'room_101',
                    createdAt: new Date().toISOString()
                }
            ];
            Storage.set(this.STORAGE_KEYS.USERS, demoUsers);
            console.log('✅ Demo users created');
        }
    },

    /**
     * Register new user (Tenant only)
     * @param {Object} userData - User data
     * @returns {Object} Result object
     */
    register(userData) {
        try {
            // Validate input
            if (!userData.email || !Validator.isEmail(userData.email)) {
                return { success: false, message: 'Email không hợp lệ' };
            }

            if (!userData.password || !Validator.minLength(userData.password, 6)) {
                return { success: false, message: 'Mật khẩu phải có ít nhất 6 ký tự' };
            }

            if (!userData.fullName || Validator.isEmpty(userData.fullName)) {
                return { success: false, message: 'Vui lòng nhập họ tên' };
            }

            if (!userData.phone || !Validator.isPhone(userData.phone)) {
                return { success: false, message: 'Số điện thoại không hợp lệ' };
            }

            // Check if email already exists
            const users = Storage.get(this.STORAGE_KEYS.USERS) || [];
            if (users.find(u => u.email === userData.email)) {
                return { success: false, message: 'Email đã được sử dụng' };
            }

            // Create new user
            const newUser = {
                id: StringUtils.generateId(),
                email: userData.email,
                password: userData.password, // Should be hashed in production
                fullName: userData.fullName,
                phone: userData.phone,
                role: this.ROLES.TENANT,
                roomId: null,
                createdAt: new Date().toISOString()
            };

            users.push(newUser);
            Storage.set(this.STORAGE_KEYS.USERS, users);

            return { 
                success: true, 
                message: 'Đăng ký thành công!',
                user: this.sanitizeUser(newUser)
            };
        } catch (error) {
            console.error('Register error:', error);
            return { success: false, message: 'Có lỗi xảy ra khi đăng ký' };
        }
    },

    /**
     * Login user
     * @param {string} email - User email
     * @param {string} password - User password
     * @returns {Object} Result object
     */
    login(email, password) {
        try {
            // Validate input
            if (!email || !Validator.isEmail(email)) {
                return { success: false, message: 'Email không hợp lệ' };
            }

            if (!password || Validator.isEmpty(password)) {
                return { success: false, message: 'Vui lòng nhập mật khẩu' };
            }

            // Find user
            const users = Storage.get(this.STORAGE_KEYS.USERS) || [];
            const user = users.find(u => u.email === email && u.password === password);

            if (!user) {
                return { success: false, message: 'Email hoặc mật khẩu không đúng' };
            }

            // Create session
            const session = {
                userId: user.id,
                role: user.role,
                loginTime: new Date().toISOString(),
                expiresAt: DateUtils.addDays(new Date(), 7).toISOString() // 7 days
            };

            Storage.set(this.STORAGE_KEYS.SESSION, session);
            Storage.set(this.STORAGE_KEYS.USER, this.sanitizeUser(user));

            return { 
                success: true, 
                message: 'Đăng nhập thành công!',
                user: this.sanitizeUser(user)
            };
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, message: 'Có lỗi xảy ra khi đăng nhập' };
        }
    },

    /**
     * Logout current user
     */
    logout() {
        Storage.remove(this.STORAGE_KEYS.USER);
        Storage.remove(this.STORAGE_KEYS.SESSION);
        window.location.href = '/auth/login.html';
    },

    /**
     * Check if user is authenticated
     * @returns {boolean}
     */
    isAuthenticated() {
        const session = Storage.get(this.STORAGE_KEYS.SESSION);
        if (!session) return false;

        // Check if session expired
        if (new Date(session.expiresAt) < new Date()) {
            this.logout();
            return false;
        }

        return true;
    },

    /**
     * Get current user
     * @returns {Object|null} Current user or null
     */
    getCurrentUser() {
        if (!this.isAuthenticated()) return null;
        return Storage.get(this.STORAGE_KEYS.USER);
    },

    /**
     * Check if current user has specific role
     * @param {string} role - Role to check
     * @returns {boolean}
     */
    hasRole(role) {
        const user = this.getCurrentUser();
        return user && user.role === role;
    },

    /**
     * Check if current user is admin
     * @returns {boolean}
     */
    isAdmin() {
        return this.hasRole(this.ROLES.ADMIN);
    },

    /**
     * Check if current user is tenant
     * @returns {boolean}
     */
    isTenant() {
        return this.hasRole(this.ROLES.TENANT);
    },

    /**
     * Require authentication (redirect if not authenticated)
     */
    requireAuth() {
        if (!this.isAuthenticated()) {
            window.location.href = '/auth/login.html';
            return false;
        }
        return true;
    },

    /**
     * Require admin role (redirect if not admin)
     */
    requireAdmin() {
        if (!this.requireAuth()) return false;
        
        if (!this.isAdmin()) {
            Notification.error('Bạn không có quyền truy cập trang này');
            window.location.href = '/tenant/portal-home.html';
            return false;
        }
        return true;
    },

    /**
     * Require tenant role (redirect if not tenant)
     */
    requireTenant() {
        if (!this.requireAuth()) return false;
        
        if (!this.isTenant()) {
            Notification.error('Bạn không có quyền truy cập trang này');
            window.location.href = '/admin/dashboard.html';
            return false;
        }
        return true;
    },

    /**
     * Update user profile
     * @param {Object} updates - Fields to update
     * @returns {Object} Result object
     */
    updateProfile(updates) {
        try {
            const currentUser = this.getCurrentUser();
            if (!currentUser) {
                return { success: false, message: 'Không tìm thấy người dùng' };
            }

            // Get all users
            const users = Storage.get(this.STORAGE_KEYS.USERS) || [];
            const userIndex = users.findIndex(u => u.id === currentUser.id);

            if (userIndex === -1) {
                return { success: false, message: 'Không tìm thấy người dùng' };
            }

            // Update user
            const updatedUser = {
                ...users[userIndex],
                ...updates,
                id: users[userIndex].id, // Prevent ID change
                role: users[userIndex].role, // Prevent role change
                updatedAt: new Date().toISOString()
            };

            users[userIndex] = updatedUser;
            Storage.set(this.STORAGE_KEYS.USERS, users);
            Storage.set(this.STORAGE_KEYS.USER, this.sanitizeUser(updatedUser));

            return { 
                success: true, 
                message: 'Cập nhật thông tin thành công!',
                user: this.sanitizeUser(updatedUser)
            };
        } catch (error) {
            console.error('Update profile error:', error);
            return { success: false, message: 'Có lỗi xảy ra khi cập nhật thông tin' };
        }
    },

    /**
     * Change password
     * @param {string} currentPassword - Current password
     * @param {string} newPassword - New password
     * @returns {Object} Result object
     */
    changePassword(currentPassword, newPassword) {
        try {
            const currentUser = this.getCurrentUser();
            if (!currentUser) {
                return { success: false, message: 'Không tìm thấy người dùng' };
            }

            // Validate input
            if (!Validator.minLength(newPassword, 6)) {
                return { success: false, message: 'Mật khẩu mới phải có ít nhất 6 ký tự' };
            }

            // Get all users
            const users = Storage.get(this.STORAGE_KEYS.USERS) || [];
            const user = users.find(u => u.id === currentUser.id);

            if (!user || user.password !== currentPassword) {
                return { success: false, message: 'Mật khẩu hiện tại không đúng' };
            }

            // Update password
            user.password = newPassword;
            user.updatedAt = new Date().toISOString();

            Storage.set(this.STORAGE_KEYS.USERS, users);

            return { 
                success: true, 
                message: 'Đổi mật khẩu thành công!'
            };
        } catch (error) {
            console.error('Change password error:', error);
            return { success: false, message: 'Có lỗi xảy ra khi đổi mật khẩu' };
        }
    },

    /**
     * Reset password (for forgot password flow)
     * @param {string} email - User email
     * @param {string} newPassword - New password
     * @returns {Object} Result object
     */
    resetPassword(email, newPassword) {
        try {
            // Validate input
            if (!Validator.isEmail(email)) {
                return { success: false, message: 'Email không hợp lệ' };
            }

            if (!Validator.minLength(newPassword, 6)) {
                return { success: false, message: 'Mật khẩu mới phải có ít nhất 6 ký tự' };
            }

            // Find user
            const users = Storage.get(this.STORAGE_KEYS.USERS) || [];
            const user = users.find(u => u.email === email);

            if (!user) {
                return { success: false, message: 'Không tìm thấy người dùng với email này' };
            }

            // Update password
            user.password = newPassword;
            user.updatedAt = new Date().toISOString();

            Storage.set(this.STORAGE_KEYS.USERS, users);

            return { 
                success: true, 
                message: 'Đặt lại mật khẩu thành công!'
            };
        } catch (error) {
            console.error('Reset password error:', error);
            return { success: false, message: 'Có lỗi xảy ra khi đặt lại mật khẩu' };
        }
    },

    /**
     * Get user by ID
     * @param {string} userId - User ID
     * @returns {Object|null} User or null
     */
    getUserById(userId) {
        const users = Storage.get(this.STORAGE_KEYS.USERS) || [];
        const user = users.find(u => u.id === userId);
        return user ? this.sanitizeUser(user) : null;
    },

    /**
     * Get user by email
     * @param {string} email - User email
     * @returns {Object|null} User or null
     */
    getUserByEmail(email) {
        const users = Storage.get(this.STORAGE_KEYS.USERS) || [];
        const user = users.find(u => u.email === email);
        return user ? this.sanitizeUser(user) : null;
    },

    /**
     * Remove sensitive data from user object
     * @param {Object} user - User object
     * @returns {Object} Sanitized user
     */
    sanitizeUser(user) {
        const { password, ...sanitized } = user;
        return sanitized;
    }
};

// ============================================
// 2. INITIALIZE AUTH ON PAGE LOAD
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    Auth.init();
    
    // Auto-redirect based on authentication status and current page
    const currentPath = window.location.pathname;
    
    // If on auth pages and already logged in, redirect to appropriate dashboard
    if (currentPath.includes('/auth/')) {
        if (Auth.isAuthenticated()) {
            if (Auth.isAdmin()) {
                window.location.href = '/admin/dashboard.html';
            } else if (Auth.isTenant()) {
                window.location.href = '/tenant/portal-home.html';
            }
        }
    }
    
    // If on admin pages, require admin role
    if (currentPath.includes('/admin/')) {
        Auth.requireAdmin();
    }
    
    // If on tenant pages, require tenant role
    if (currentPath.includes('/tenant/')) {
        Auth.requireTenant();
    }

    // Display current user info if logged in
    const user = Auth.getCurrentUser();
    if (user) {
        // Update user info in header/navbar if exists
        const userNameElements = document.querySelectorAll('.user-name');
        userNameElements.forEach(el => {
            el.textContent = user.fullName;
        });

        const userEmailElements = document.querySelectorAll('.user-email');
        userEmailElements.forEach(el => {
            el.textContent = user.email;
        });

        const userRoleBadges = document.querySelectorAll('.user-role-badge');
        userRoleBadges.forEach(el => {
            el.textContent = user.role === 'admin' ? 'Quản lý' : 'Người thuê';
        });
    }

    // Setup logout buttons
    const logoutButtons = document.querySelectorAll('.logout-btn, [data-logout]');
    logoutButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            if (confirm('Bạn có chắc muốn đăng xuất?')) {
                Auth.logout();
            }
        });
    });
});

// Make Auth available globally
window.Auth = Auth;

console.log('✅ Authentication system loaded');