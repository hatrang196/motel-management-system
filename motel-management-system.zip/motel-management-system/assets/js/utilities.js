/*
==============================================
  MOTEL MANAGEMENT SYSTEM - UTILITIES
==============================================
  Helper functions and utilities
==============================================
*/

// ============================================
// 1. LOCAL STORAGE HELPER
// ============================================

const Storage = {
    /**
     * Get item from localStorage
     */
    get(key) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : null;
        } catch (error) {
            console.error('Storage get error:', error);
            return null;
        }
    },

    /**
     * Set item in localStorage
     */
    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            console.error('Storage set error:', error);
            return false;
        }
    },

    /**
     * Remove item from localStorage
     */
    remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error('Storage remove error:', error);
            return false;
        }
    },

    /**
     * Clear all localStorage
     */
    clear() {
        try {
            localStorage.clear();
            return true;
        } catch (error) {
            console.error('Storage clear error:', error);
            return false;
        }
    }
};

// ============================================
// 2. VALIDATION UTILITIES
// ============================================

const Validator = {
    /**
     * Check if value is empty
     */
    isEmpty(value) {
        return value === null || value === undefined || value.toString().trim() === '';
    },

    /**
     * Validate email
     */
    isEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    /**
     * Validate phone number (Vietnamese format)
     */
    isPhone(phone) {
        const phoneRegex = /^(0|\+84)[3|5|7|8|9][0-9]{8}$/;
        return phoneRegex.test(phone.replace(/\s/g, ''));
    },

    /**
     * Check minimum length
     */
    minLength(value, length) {
        return value && value.toString().length >= length;
    },

    /**
     * Check maximum length
     */
    maxLength(value, length) {
        return value && value.toString().length <= length;
    },

    /**
     * Check if value is number
     */
    isNumber(value) {
        return !isNaN(parseFloat(value)) && isFinite(value);
    },

    /**
     * Check if value is positive number
     */
    isPositiveNumber(value) {
        return this.isNumber(value) && parseFloat(value) > 0;
    },

    /**
     * Validate date format (YYYY-MM-DD)
     */
    isDate(date) {
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateRegex.test(date)) return false;
        const d = new Date(date);
        return d instanceof Date && !isNaN(d);
    },

    /**
     * Check if date is in the future
     */
    isFutureDate(date) {
        return new Date(date) > new Date();
    },

    /**
     * Check if date is in the past
     */
    isPastDate(date) {
        return new Date(date) < new Date();
    }
};

// ============================================
// 3. DATE UTILITIES
// ============================================

const DateUtils = {
    /**
     * Format date to Vietnamese format (DD/MM/YYYY)
     */
    formatDate(date) {
        const d = new Date(date);
        const day = String(d.getDate()).padStart(2, '0');
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const year = d.getFullYear();
        return `${day}/${month}/${year}`;
    },

    /**
     * Format date to ISO format (YYYY-MM-DD)
     */
    formatDateISO(date) {
        const d = new Date(date);
        const day = String(d.getDate()).padStart(2, '0');
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const year = d.getFullYear();
        return `${year}-${month}-${day}`;
    },

    /**
     * Format datetime (DD/MM/YYYY HH:MM)
     */
    formatDateTime(date) {
        const d = new Date(date);
        const dateStr = this.formatDate(d);
        const hours = String(d.getHours()).padStart(2, '0');
        const minutes = String(d.getMinutes()).padStart(2, '0');
        return `${dateStr} ${hours}:${minutes}`;
    },

    /**
     * Get current date in ISO format
     */
    getCurrentDate() {
        return this.formatDateISO(new Date());
    },

    /**
     * Add days to date
     */
    addDays(date, days) {
        const result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    },

    /**
     * Add months to date
     */
    addMonths(date, months) {
        const result = new Date(date);
        result.setMonth(result.getMonth() + months);
        return result;
    },

    /**
     * Calculate difference in days
     */
    daysDifference(date1, date2) {
        const d1 = new Date(date1);
        const d2 = new Date(date2);
        const diffTime = Math.abs(d2 - d1);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    },

    /**
     * Get month name in Vietnamese
     */
    getMonthName(month) {
        const months = [
            'Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4',
            'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8',
            'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'
        ];
        return months[month];
    },

    /**
     * Get relative time (e.g., "2 giờ trước")
     */
    getRelativeTime(date) {
        const now = new Date();
        const past = new Date(date);
        const diffMs = now - past;
        const diffSec = Math.floor(diffMs / 1000);
        const diffMin = Math.floor(diffSec / 60);
        const diffHour = Math.floor(diffMin / 60);
        const diffDay = Math.floor(diffHour / 24);

        if (diffSec < 60) return 'Vừa xong';
        if (diffMin < 60) return `${diffMin} phút trước`;
        if (diffHour < 24) return `${diffHour} giờ trước`;
        if (diffDay < 30) return `${diffDay} ngày trước`;
        return this.formatDate(date);
    }
};

// ============================================
// 4. NUMBER UTILITIES
// ============================================

const NumberUtils = {
    /**
     * Format number as Vietnamese currency
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount);
    },

    /**
     * Format number with thousand separators
     */
    formatNumber(number) {
        return new Intl.NumberFormat('vi-VN').format(number);
    },

    /**
     * Parse formatted number back to number
     */
    parseNumber(formattedNumber) {
        return parseFloat(formattedNumber.replace(/[^0-9.-]+/g, ''));
    },

    /**
     * Round to decimal places
     */
    round(number, decimals = 0) {
        return Math.round(number * Math.pow(10, decimals)) / Math.pow(10, decimals);
    },

    /**
     * Generate random number between min and max
     */
    random(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
};

// ============================================
// 5. STRING UTILITIES
// ============================================

const StringUtils = {
    /**
     * Capitalize first letter
     */
    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
    },

    /**
     * Convert to title case
     */
    toTitleCase(str) {
        return str.replace(/\w\S*/g, txt => 
            txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
        );
    },

    /**
     * Truncate string
     */
    truncate(str, length, suffix = '...') {
        if (str.length <= length) return str;
        return str.substring(0, length) + suffix;
    },

    /**
     * Remove accents from Vietnamese text
     */
    removeAccents(str) {
        return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    },

    /**
     * Generate slug from string
     */
    slugify(str) {
        return this.removeAccents(str)
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
    },

    /**
     * Generate random ID
     */
    generateId(prefix = '') {
        const timestamp = Date.now().toString(36);
        const random = Math.random().toString(36).substring(2, 9);
        return prefix ? `${prefix}_${timestamp}${random}` : `${timestamp}${random}`;
    },

    /**
     * Generate random OTP
     */
    generateOTP(length = 6) {
        return Math.floor(Math.random() * Math.pow(10, length))
            .toString()
            .padStart(length, '0');
    },

    /**
     * Mask email (e.g., j***@gmail.com)
     */
    maskEmail(email) {
        const [name, domain] = email.split('@');
        const maskedName = name[0] + '***' + name[name.length - 1];
        return `${maskedName}@${domain}`;
    },

    /**
     * Mask phone (e.g., 090***5678)
     */
    maskPhone(phone) {
        return phone.replace(/(\d{3})\d{4}(\d{3})/, '$1***$2');
    }
};

// ============================================
// 6. NOTIFICATION UTILITIES
// ============================================

const Notification = {
    /**
     * Show success notification
     */
    success(message, duration = 3000) {
        this.show(message, 'success', duration);
    },

    /**
     * Show error notification
     */
    error(message, duration = 5000) {
        this.show(message, 'error', duration);
    },

    /**
     * Show warning notification
     */
    warning(message, duration = 4000) {
        this.show(message, 'warning', duration);
    },

    /**
     * Show info notification
     */
    info(message, duration = 3000) {
        this.show(message, 'info', duration);
    },

    /**
     * Show notification
     */
    show(message, type = 'info', duration = 3000) {
        // Remove existing notifications
        const existing = document.querySelector('.notification-toast');
        if (existing) existing.remove();

        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification-toast notification-${type}`;
        notification.textContent = message;

        // Add to body
        document.body.appendChild(notification);

        // Show notification
        setTimeout(() => notification.classList.add('show'), 10);

        // Auto remove
        if (duration > 0) {
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => notification.remove(), 300);
            }, duration);
        }
    }
};

// Add notification styles
if (!document.getElementById('notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        .notification-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px 24px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            font-size: 14px;
            font-weight: 500;
            z-index: 9999;
            transform: translateX(400px);
            transition: transform 0.3s ease-in-out;
            max-width: 400px;
        }
        .notification-toast.show {
            transform: translateX(0);
        }
        .notification-success {
            background-color: #10B981;
            color: white;
        }
        .notification-error {
            background-color: #EF4444;
            color: white;
        }
        .notification-warning {
            background-color: #F59E0B;
            color: white;
        }
        .notification-info {
            background-color: #3B82F6;
            color: white;
        }
    `;
    document.head.appendChild(style);
}

// ============================================
// 7. CONFIRMATION DIALOG
// ============================================

const ConfirmDialog = {
    /**
     * Show confirmation dialog
     */
    show(options = {}) {
        return new Promise((resolve) => {
            const {
                title = 'Xác nhận',
                message = 'Bạn có chắc chắn muốn thực hiện hành động này?',
                confirmText = 'Xác nhận',
                cancelText = 'Hủy',
                type = 'warning'
            } = options;

            // Remove existing dialog
            const existing = document.querySelector('.confirm-dialog-backdrop');
            if (existing) existing.remove();

            // Create backdrop
            const backdrop = document.createElement('div');
            backdrop.className = 'confirm-dialog-backdrop';

            // Create dialog
            const dialog = document.createElement('div');
            dialog.className = 'confirm-dialog';
            dialog.innerHTML = `
                <div class="confirm-dialog-header">
                    <h3>${title}</h3>
                </div>
                <div class="confirm-dialog-body">
                    <p>${message}</p>
                </div>
                <div class="confirm-dialog-footer">
                    <button class="btn-cancel">${cancelText}</button>
                    <button class="btn-confirm btn-${type}">${confirmText}</button>
                </div>
            `;

            backdrop.appendChild(dialog);
            document.body.appendChild(backdrop);

            // Show dialog
            setTimeout(() => backdrop.classList.add('show'), 10);

            // Handle buttons
            const btnCancel = dialog.querySelector('.btn-cancel');
            const btnConfirm = dialog.querySelector('.btn-confirm');

            btnCancel.onclick = () => {
                backdrop.classList.remove('show');
                setTimeout(() => backdrop.remove(), 300);
                resolve(false);
            };

            btnConfirm.onclick = () => {
                backdrop.classList.remove('show');
                setTimeout(() => backdrop.remove(), 300);
                resolve(true);
            };

            // Close on backdrop click
            backdrop.onclick = (e) => {
                if (e.target === backdrop) {
                    backdrop.classList.remove('show');
                    setTimeout(() => backdrop.remove(), 300);
                    resolve(false);
                }
            };
        });
    }
};

// Add confirm dialog styles
if (!document.getElementById('confirm-dialog-styles')) {
    const style = document.createElement('style');
    style.id = 'confirm-dialog-styles';
    style.textContent = `
        .confirm-dialog-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s ease-in-out;
        }
        .confirm-dialog-backdrop.show {
            opacity: 1;
        }
        .confirm-dialog {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        .confirm-dialog-header {
            padding: 20px 24px;
            border-bottom: 1px solid #E5E7EB;
        }
        .confirm-dialog-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
        }
        .confirm-dialog-body {
            padding: 20px 24px;
        }
        .confirm-dialog-body p {
            margin: 0;
            color: #6B7280;
            line-height: 1.5;
        }
        .confirm-dialog-footer {
            padding: 16px 24px;
            border-top: 1px solid #E5E7EB;
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }
        .confirm-dialog-footer button {
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-cancel {
            background: white;
            color: #374151;
            border: 1px solid #D1D5DB !important;
        }
        .btn-cancel:hover {
            background: #F9FAFB;
        }
        .btn-confirm {
            background: #77C47C;
            color: white;
        }
        .btn-confirm:hover {
            background: #66b36b;
        }
        .btn-confirm.btn-danger {
            background: #EF4444;
        }
        .btn-confirm.btn-danger:hover {
            background: #DC2626;
        }
    `;
    document.head.appendChild(style);
}

// ============================================
// 8. MAKE UTILITIES AVAILABLE GLOBALLY
// ============================================

window.Storage = Storage;
window.Validator = Validator;
window.DateUtils = DateUtils;
window.NumberUtils = NumberUtils;
window.StringUtils = StringUtils;
window.Notification = Notification;
window.ConfirmDialog = ConfirmDialog;

console.log('Utilities loaded');